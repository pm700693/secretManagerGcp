package com.secret.secret;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Base64;

@RestController
public class GcpSecretController {
	
 
   
   
   @Autowired
   private GcpSecretManagerService cryptoService;
   
   @Value("${sm://samplePass}")
   String cipherText;

   @PostMapping("/decrypt")
   public String decrypt(
           @RequestParam String keyId) {

       return "Decrypted Text= " +
               cryptoService.decrypt(keyId,cipherText);
   }
}