package com.secret.secret;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecretApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecretApplication.class, args);
	}

}
