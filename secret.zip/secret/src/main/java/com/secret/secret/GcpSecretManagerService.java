package com.secret.secret;

import com.google.cloud.kms.v1.CryptoKeyName;
import com.google.cloud.kms.v1.DecryptResponse;
import com.google.cloud.kms.v1.KeyManagementServiceClient;
import com.google.cloud.secretmanager.v1.AccessSecretVersionRequest;
import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretPayload;
import com.google.cloud.spring.kms.KmsTemplate;
import com.google.protobuf.ByteString;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.cloud.kms.v1.CryptoKeyName;
import com.google.cloud.kms.v1.EncryptResponse;
import com.google.cloud.kms.v1.KeyManagementServiceClient;
import com.google.cloud.secretmanager.v1.AccessSecretVersionRequest;
import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.CreateSecretRequest;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.protobuf.ByteString;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Base64;

@Service
public class GcpSecretManagerService {

   private final SecretManagerServiceClient secretManagerServiceClient;
   private final KeyManagementServiceClient keyManagementServiceClient;
   
   
   @Autowired
   private KmsTemplate kmsTemplate;

   public GcpSecretManagerService() throws IOException {
       secretManagerServiceClient = SecretManagerServiceClient.create();
       keyManagementServiceClient = KeyManagementServiceClient.create();
   }

  
   
   public String decrypt(String keyId, String cipherText) {

       byte[] decryptedBytes = decodeBase64(cipherText);
       String decrypted = kmsTemplate.
               decryptText(keyId, decryptedBytes);

       return decrypted;
   }
   private byte[] decodeBase64(String encryptedText) {
       byte[] bytes = encryptedText.getBytes();
       return Base64.getDecoder().decode(bytes);
   }
}
